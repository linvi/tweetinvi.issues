﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tweetinvi;

namespace RuntimeComponent2
{
    public sealed class Class1
    {
        public Class1()
        {
            // Set up your credentials (https://apps.twitter.com)
            Auth.SetUserCredentials("CONSUMER_KEY", "CONSUMER_SECRET", "ACCESS_TOKEN", "ACCESS_TOKEN_SECRET");

            // Publish the Tweet "Hello World" on your Timeline
            Tweet.PublishTweet("Hello World!");
        }
    }
}
